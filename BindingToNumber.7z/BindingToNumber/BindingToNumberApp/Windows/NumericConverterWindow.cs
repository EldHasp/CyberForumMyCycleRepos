﻿using System.Windows;

namespace AppBindingToNumeric
{
    /// <summary>
    /// Логика взаимодействия для BindNumberWInd.xaml
    /// </summary>
    public partial class NumericConverterWindow : Window
    {
        public NumericConverterWindow()
        {
            InitializeComponent();
        }

    }




}
