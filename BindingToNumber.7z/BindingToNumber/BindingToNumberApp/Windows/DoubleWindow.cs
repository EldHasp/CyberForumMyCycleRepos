﻿using System.Windows;

namespace AppBindingToNumeric
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class DoubleWindow : Window
    {
        public DoubleWindow()
        {
            InitializeComponent();
        }
    }

}
