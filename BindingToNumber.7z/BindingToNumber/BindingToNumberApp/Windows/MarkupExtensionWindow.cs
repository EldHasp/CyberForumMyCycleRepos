﻿using System.Windows;

namespace AppBindingToNumeric
{
    /// <summary>
    /// Логика взаимодействия для BindExtendingMarkupWind.xaml
    /// </summary>
    public partial class MarkupExtensionWindow : Window
    {
        public MarkupExtensionWindow()
        {
            InitializeComponent();
        }
    }
}
